package com.example.xxx.todolist;

import android.content.Context;
import android.graphics.Paint;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;


import java.util.LinkedList;
import java.util.List;

public class ButtonAdapter extends RecyclerView.Adapter<ButtonAdapter.ViewHolder> {
    private List<Task> task = new LinkedList<>();
    private LayoutInflater Inflater;
    private ItemClickListener mClickListener;


    // data is passed into the constructor
    ButtonAdapter(Context context, List<Task> task) {
        this.Inflater = LayoutInflater.from(context);
        this.task = task;
    }

    // inflates the cell layout from xml when needed
    @Override

    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = Inflater.inflate(R.layout.recycle_button, parent, false);
        return new ViewHolder(view);

    }

    // binds the data to the TextView in each cell
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {




    }

    // total number of cells
    @Override
    public int getItemCount() {
        return task.size();
    }


    // stores and recycles views as they are scrolled off screen
    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
       FloatingActionButton minus;

        ViewHolder(View itemView) {
            super(itemView);
        minus=itemView.findViewById(R.id.floati);
            minus.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (mClickListener != null) mClickListener.onItemClick(view, getAdapterPosition());
        }
    }

    // allows clicks events to be caught
    void setClickListener(ItemClickListener itemClickListener) {
        this.mClickListener = itemClickListener;
    }

        // parent activity will implement this method to respond to click events
        public interface ItemClickListener {
            void onItemClick(View view, int position);

        }
    }


