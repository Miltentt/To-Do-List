package com.example.xxx.todolist;

import android.arch.persistence.room.Room;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class DeleteActivity extends AppCompatActivity implements ButtonAdapter.ItemClickListener
{
    private RecyclerView recyclerView;
    private RecycleViewAdapter adapter;
    private List<Task> task = new LinkedList();
    private DataBase db;
    private LinearLayout linear;
    private RecyclerView recyclerView1;
    private ButtonAdapter adapter1;
    private ArrayList positions = new ArrayList();


    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.deleteactivity);
        db = Room.databaseBuilder(getApplicationContext(), DataBase.class, "Taskbase1")
                .allowMainThreadQueries()
                .build();
        task = db.taskDao().loadAllTasks();
        linear = (LinearLayout) findViewById(R.id.linear);
        recyclerView = (RecyclerView) findViewById(R.id.tasks);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView1 = (RecyclerView) findViewById(R.id.floatingbuttons);
        recyclerView1.setLayoutManager(new LinearLayoutManager(this));
        adapter = new RecycleViewAdapter(this, task);
        recyclerView.setAdapter(adapter);
        adapter1 = new ButtonAdapter(this, task);
        adapter1.setClickListener(this);
        recyclerView1.setAdapter(adapter1);

    }


    @Override
    public void onItemClick(View view, int position) {

       db.taskDao().delete(task.get(position));
positions.add(position);
       task.remove(position);
       adapter.notifyDataSetChanged();
       adapter1.notifyDataSetChanged();
    }

    public void back (View view)
    {
        Bundle extras = new Bundle();
        Intent i = new Intent();
        final EditText NameInput = (EditText) findViewById(R.id.Name);

        extras.putParcelableArrayList("positions",positions);
        i.putExtras(extras);
        setResult(RESULT_OK,i);
        finish();



    }
}
